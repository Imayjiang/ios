/*
 Copyright (C) 2015 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 The primary view controller for displaying iCloud documents.
 */

#import <UIKit/UIKit.h>

@interface AAPLTableViewController : UITableViewController

@end
